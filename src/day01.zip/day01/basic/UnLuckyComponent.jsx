import React from 'react';

const UnLuckyComponent = () => {
  const unLucky ="꽝";
  return (
    <div>
      {unLucky}
    </div>
  );
};

export default UnLuckyComponent;