const Jsx01 = () => {
  return (
    <div>
      나의 첫 컴포넌트! 😊
    </div>
  )
}

export default Jsx01;