import React from 'react';

const NotPassComponent = () => {
  const notPass = "입장 불가";
  return (
    <div>
      {notPass}
    </div>
  );
};

export default NotPassComponent;