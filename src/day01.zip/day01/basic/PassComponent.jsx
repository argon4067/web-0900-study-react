import React from 'react';

const PassComponent = () => {
  const pass ="입장 가능";
  
  return (
    <div>
      {pass}
      
    </div>
  );
};

export default PassComponent;