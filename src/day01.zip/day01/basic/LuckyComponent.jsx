import React from 'react';

const LuckyComponent = () => {
  const lucky= "당첨";
  return (
    <div>
      {lucky}
    </div>
  );
};

export default LuckyComponent;